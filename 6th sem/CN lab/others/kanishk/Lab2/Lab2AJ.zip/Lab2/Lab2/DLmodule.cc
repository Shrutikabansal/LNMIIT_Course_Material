//
// This program is free software: you can redistribute it and/or modify
// it under the terms of the GNU Lesser General Public License as published by
// the Free Software Foundation, either version 3 of the License, or
// (at your option) any later version.
// 
// This program is distributed in the hope that it will be useful,
// but WITHOUT ANY WARRANTY; without even the implied warranty of
// MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
// GNU Lesser General Public License for more details.
// 
// You should have received a copy of the GNU Lesser General Public License
// along with this program.  If not, see http://www.gnu.org/licenses/.
// 

#include "DLmodule.h"
#include "N_PDU_m.h"
#include "DL_PDU_m.h"

Define_Module(DLmodule);

void DLmodule::initialize()
{
    // TODO - Generated method body
    id=par("Did");
    Nin=gate("N_gIn");
    Nout=gate("N_gOut");
    Din=gate("D_gIn");
    Dout=gate("D_gOut");
}

void DLmodule::handleMessage(cMessage *msg)
{
    // TODO - Generated method body

    if(msg->getArrivalGate()==Nin){
        N_PDU *N_msg=check_and_cast<N_PDU *>(msg);
        DL_PDU *D_msg= new DL_PDU("data");
        D_msg->setDId(N_msg->getPId());
        D_msg->setDType("data");
        D_msg->encapsulate(N_msg);
        send(D_msg,Dout);

    }else if(msg->getArrivalGate()==Din){
        DL_PDU *D_msg=check_and_cast<DL_PDU *>(msg);
        if(D_msg->getDType()=="Ack")
            delete(D_msg);
        else{
            DL_PDU *D_msg_ack= new DL_PDU("Ack");
            D_msg_ack->setDId(D_msg->getDId());
            D_msg_ack->setDType("Ack");
            send(D_msg_ack,Dout);
            send(D_msg->decapsulate(),Nout);
        }

    }



}
