%We can call a function using a script file, command promt and another
%function file

vel=Class_3_1(12,70,0.25);

