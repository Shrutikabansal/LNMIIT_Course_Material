function x=pivotalgauss(A)
    
    [n,m]=size(A);
    
    for k=1:n-1


end