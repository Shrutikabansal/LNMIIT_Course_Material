clear all;
close all;

hp=0.05;
Tinf=200;
Ta=300;
Tb=400;
dx=0.01;
L=10;
m=L/dx;

